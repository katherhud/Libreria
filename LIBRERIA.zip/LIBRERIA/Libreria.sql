Create Database LibreriaDB
use LibreriaDB
-- Tabla de Alumnos
CREATE TABLE Alumnos (
    AlumnoID INT IDENTITY PRIMARY KEY,
    Matricula VARCHAR(15),
    Nombre VARCHAR(50),
    Apellidos VARCHAR(100),
    Telefono VARCHAR(10) NULL,
    PrestamosActivos INT
);

-- Tabla de Libros
CREATE TABLE Libros (
    LibroID INT IDENTITY PRIMARY KEY,
    Titulo VARCHAR(150),
    Autor VARCHAR(100),
    ISBN VARCHAR(13),
    Disponible BIT -- 1 = DISPONIBLE, 0 = PRESTADO
);


-- Tabla de Prestamos
CREATE TABLE Prestamos (
    PrestamoID INT IDENTITY PRIMARY KEY,
    UsuarioID INT, -- Foreign Key a Alumnos
    LibroID INT,   -- Foreign Key a Libros
    FechaPrestamo DATETIME,
    FechaDevolucion DATETIME NULL,
    Multa DECIMAL(10,2), -- Multa por retraso (0 si no aplica)

    -- Claves for�neas
    FOREIGN KEY (UsuarioID) REFERENCES Alumnos(AlumnoID),
    FOREIGN KEY (LibroID) REFERENCES Libros(LibroID)
);


select * from Libros

INSERT INTO Libros (Titulo, Autor, ISBN, Disponible)
VALUES
('Introduccion a la estructuras de datos', 'Jorge A. Villalobos S.', '9789586991049', 1),
('Estructura de datos en JAVA', 'Mark Allen Weiss', '978478290354', 1),
('Sistemas de base de datos', 'Alice Y. H. Tsai', '979688801810', 1),
('Contabilidad de sociedades', 'Ma. Elena Morales', '9786071509833', 1),
('Contabilidad un enfoque aplicada a Mexico', 'Horngreen Harrison', '9702604923', 1),
('Macroeconomia', 'Michael Parkin', '978607323340', 1),
('Economia critica', 'Sergio A. Berumen', '9789682481505', 1),
('Programacion con PYTHON', 'Alexander Cane', '9781699058701', 1),
('Fundamentos de Economia', 'Ana Graue', '9786074423180', 1),
('Introduccion al crecimiento economico', 'Charles I.Jones', '9684444109', 1),
('MySQL para Windows y Linux', 'Cesar Perez', '9789701513255', 1),
('Microsoft C# lenguaje y aplicaciones', 'Javier Ceballos', '9789701513712', 1),
('Auditoria informatica', 'Mario G. Piattini', '9701507312', 1),
('Economia internacional', 'Divvio Gallegos Paniagua', '9786071703941', 1),
('La auditoria administrativa', 'Eduardo Mancillas Perez', '9789682476482', 1),
('Primer curso de contabilidad','Elias Lara Ramirez', '9786071727008', 1),
('Calculo integral', 'Benjamin Garza Olvera', '9786073230636', 1),
('Analisis y dise�o de sistema de informacion', 'James Senn', '9684229917', 1),
('Las computadoras y la informacion', 'Lawrence Orilia', '9684512651', 1),
('Estructura de datos orientada a objetos', 'Bruno Lopez Takeyas', '9786077075295', 1),
('Estructura de computadores y perifericos', 'Rafael Martinez Dura', '9701506901', 1),
('PYTHON para principiantes', 'Daniel Correa', '9798370698637', 1),
('Contabilidad basica', 'Joaquin Moreno Fernandez', '9702402247', 1),
('Contabilidad 1', 'Fracisco Calleja Bernal', '9786073203340', 1),
('Python para todos: Explorando la informaci�n', 'Charles Severance', '9788415785085', 1),
('Marketing:principios', 'Philip Kotler', '9786073233481', 1),
('Auditoria un enfoque general', 'Alvin Arens', '9786073215289', 1),
('Introduccion a la contabilidad', 'Charles Horngren', '9789702609028', 1),
('SQL Server para Desarrolladores', ' Miguel �ngel Mar�n', '9781890774677', 1),
('Comercio Internacional: Teor�a y Pol�tica', 'Paul R. Krugman', '9788448152343', 1),
('Introducci�n a la Auditor�a', 'Hugo Sandoval Morales', '9786077331377', 1),
('Contabilidad de Costos', 'Charles T. Horngren', '9786073233832', 1),
('Auditor�a de Sistemas: Una perspectiva integral', 'Mario G. Piattini', '9788428328173', 1),
('Principios de contabilidad','Carlos Garcia','9789706866160',1),
('La riqueza de las naciones','Adam Smith','9788420677461',1),
('Manual de desarrollo �gil de software','Roberto Martin','9788441527781',1),
('MongoDB: La base de datos NoSQL','Ricard Forner','9788415309395',1),
('Microeconom�a intermedia',' Hal Varian','9788490352520',1),
('Marketing y ventas para emprendedores','Carlos Escribano','9788494911479',1);,
('Fundamentos de algoritmos','Thomas H. Cormen','9788420556155',1);

select * from Libros
select * from Alumnos