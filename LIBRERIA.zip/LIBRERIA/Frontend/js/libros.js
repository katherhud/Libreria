const formLibros = document.getElementById('formLibros');
const tablaLibros = document.getElementById('tablaLibros');
const API_URL = 'http://localhost:5262'; // puerto de la API

// Variable global para almacenar todos los libros cargados de la API
let libros = []; 

// Listar libros (Carga Inicial y Recarga) 
async function listarLibros() {
  try {
    const res = await fetch(`${API_URL}/api/libros`);
    
    // Verifica si la respuesta es exitosa
    if (!res.ok) {
        // Lanza un error si el código HTTP no es 200-299 (correcto)
        throw new Error(`Error HTTP: ${res.status}`);
    }
    
    // Almacena la lista completa en la variable global 'libros'
    libros = await res.json(); 
    mostrarLibros(libros); // Muestra la lista completa al inicio
  } catch (error) {
    console.error('Error al listar libros:', error);
    tablaLibros.innerHTML = '<tr><td colspan="4" style="text-align: center; color: red;">Error al cargar la lista de libros.</td></tr>';
  }
}

// Mostrar libros en tabla 
function mostrarLibros(lista) {
  tablaLibros.innerHTML = '';

  if (!lista || lista.length === 0) {
      tablaLibros.innerHTML = '<tr><td colspan="4" style="text-align: center;">No hay libros para mostrar.</td></tr>';
      return;
  }
  
  lista.forEach(libro => {
    const fila = document.createElement('tr');
    // Aplicamos estilos de color basados en el estado
    const estadoTexto = libro.disponible ? '<span style="color: green; font-weight: bold;">Disponible</span>' : '<span style="color: var(--color-primario); font-weight: bold;">Prestado</span>';
    
    fila.innerHTML = `
      <td>${libro.titulo}</td>
      <td>${libro.autor}</td>
      <td>${libro.isbn}</td>
      <td>${estadoTexto}</td>
    `;
    tablaLibros.appendChild(fila);
  });
}


// Filtrar libros (Usa la lista global 'libros') 
function filtrarLibros(estado) {
  let listaFiltrada = [];
  
  if (estado === 'todos') {
    listaFiltrada = libros; // Usa la lista completa
  } else if (estado === 'disponibles') {
    // Filtra la lista global, solo donde disponible es true
    listaFiltrada = libros.filter(l => l.disponible === true); 
  } else if (estado === 'prestados') {
    // Filtra la lista global, solo donde disponible es false
    listaFiltrada = libros.filter(l => l.disponible === false);
  }
  
  mostrarLibros(listaFiltrada);
}

// Registrar libro (Desde el formulario)
formLibros.addEventListener('submit', async e => {
    e.preventDefault();

    const nuevoLibro = {
        titulo: document.getElementById('titulo').value.trim(),
        autor: document.getElementById('autor').value.trim(),
        isbn: document.getElementById('isbn').value.trim(),
        disponible: true
    };

    if (nuevoLibro.isbn.length !== 13) {
        alert('El ISBN debe tener 13 caracteres');
        return;
    }

    try {
        const res = await fetch(`${API_URL}/api/libros`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevoLibro)
        });

        if (!res.ok) {
             const errorText = await res.text();
             throw new Error(`Error al registrar: ${errorText}`);
        }

        formLibros.reset();
        listarLibros(); // Recarga la lista GLOBAL y la tabla
    } catch (error) {
        console.error('Error al registrar libro:', error);
        alert('Ocurrió un error al registrar el libro. Revisa la consola.');
    }
});

// Cargar libros apenas abriendo la página 
listarLibros();

