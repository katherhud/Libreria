const formUsuarios = document.getElementById('formUsuarios');
const tablaUsuarios = document.getElementById('tablaUsuarios');

const API_URL = 'http://localhost:5262'; // puerto de la API

// Listar Usuarios (Al abrir la página y después de registrar) 
async function listarUsuarios() {
    try {
        // La ruta es /api/usuarios, forzada en el controlador C#
        const res = await fetch(`${API_URL}/api/usuarios`); 
        
        if (!res.ok) {
            throw new Error(`Error HTTP: ${res.status}`);
        }
        
        const usuarios = await res.json();

        tablaUsuarios.innerHTML = ''; // Limpia la tabla antes de llenarla

        if (!usuarios || usuarios.length === 0) {
            tablaUsuarios.innerHTML = '<tr><td colspan="4" style="text-align: center;">No hay usuarios registrados.</td></tr>';
            return;
        }

        usuarios.forEach(user => {
            const fila = document.createElement('tr');
            // Muestra las propiedades de usuario
            fila.innerHTML = `
                <td>${user.matricula}</td>
                <td>${user.nombre}</td>
                <td>${user.apellidos}</td>
                <td>${user.telefono}</td>
            `;
            tablaUsuarios.appendChild(fila);
        });

    } catch (error) {
        console.error('Error al cargar la lista de usuarios:', error);
        tablaUsuarios.innerHTML = '<tr><td colspan="4" style="text-align: center; color: red;">Error al cargar la lista de usuarios.</td></tr>';
    }
}

// Registrar Usuario 
formUsuarios.addEventListener('submit', async e => {
    e.preventDefault();

    const nuevoUsuario = {
        Matricula: document.getElementById('matricula').value.trim(),
        Nombre: document.getElementById('nombre').value.trim(),
        Apellidos: document.getElementById('apellidos').value.trim(),
        Telefono: document.getElementById('telefono').value.trim()
    };

    if (!nuevoUsuario.Matricula) {
        alert('La matrícula no puede estar vacía');
        return;
    }

    try {
        // La ruta forzada es /api/usuarios 
        const res = await fetch(`${API_URL}/api/usuarios`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevoUsuario)
        });

        if (!res.ok) {
             const errorText = await res.text();
             // Muestra el mensaje de error real del servidor
             throw new Error(`Error al registrar: ${errorText}`);
        }
        
        formUsuarios.reset(); 
        listarUsuarios(); // Recarga la tabla para mostrar el nuevo usuario inmediatamente

    } catch (error) {
        console.error('Error al registrar usuario:', error);
        // Muestra una alerta con un mensaje de error genérico
        alert('Ocurrió un error al registrar el usuario. Revisa la consola para detalles.');
    }
});

// Cargar usuarios al abrir la página 
listarUsuarios();

