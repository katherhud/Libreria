const API_URL = 'http://localhost:5262'; // URL de la API
const btnPrestar = document.getElementById('btnPrestar'); // Botón de Préstamo
const filtroActivosInput = document.getElementById('filtroActivos'); // Input de filtro activos
// Elementos de la tabla
const tablaActivos = document.getElementById('tablaPrestamosActivos');
const tablaHistorial = document.getElementById('tablaHistorialCompleto');

let historialCompleto = []; // Variable global para el historial

// Funciones para Cargar Selects de Usuarios y Libros

async function cargarUsuariosSelect() {
    try {
        const res = await fetch(`${API_URL}/api/usuarios`); 
        if (!res.ok) throw new Error(`Error HTTP: ${res.status}`);
        
        const usuarios = await res.json();
        const usuarioSelect = document.getElementById('usuarioSelect');
        
        usuarioSelect.innerHTML = '<option value="">-- Seleccionar Usuario --</option>';

        usuarios.forEach(user => {
            usuarioSelect.innerHTML += `<option value="${user.usuarioId}">${user.nombre} ${user.apellidos}</option>`;
        });

    } catch (error) {
        console.error('FALLO CRÍTICO al cargar usuarios para el SELECT:', error);
        const usuarioSelect = document.getElementById('usuarioSelect');
        if (usuarioSelect) usuarioSelect.innerHTML = '<option>--- Fallo de Conexión ---</option>';
    }
}

async function cargarLibrosSelect() {
    try {
        const res = await fetch(`${API_URL}/api/libros`);
        if (!res.ok) throw new Error(`Error HTTP: ${res.status}`);

        const libros = await res.json();
        const libroSelect = document.getElementById('libroSelect');
        
        libroSelect.innerHTML = '<option value="">-- Seleccionar Libro --</option>';

        // Filtro para mostrar solo libros disponibles
        libros.filter(l => l.disponible === true).forEach(libro => {
            libroSelect.innerHTML += `<option value="${libro.libroId}">${libro.titulo} (${libro.autor})</option>`;
        });
    } catch (error) {
        console.error('FALLO CRÍTICO al cargar libros para el SELECT:', error);
        const libroSelect = document.getElementById('libroSelect');
        if (libroSelect) libroSelect.innerHTML = '<option>--- Fallo de Conexión ---</option>';
    }
}

function cargarOpciones() {
    cargarUsuariosSelect();
    cargarLibrosSelect();
}


// Funciones de Préstamo y Devolución 

// Registro de Préstamos 
if (btnPrestar) { 
    btnPrestar.addEventListener('click', async e => {
        e.preventDefault();
        const usuarioId = parseInt(document.getElementById('usuarioSelect').value);
        const libroId = parseInt(document.getElementById('libroSelect').value);

        if (!usuarioId || !libroId) {
            alert('Por favor selecciona un usuario y un libro.');
            return;
        }

        try {
            const res = await fetch(`${API_URL}/api/prestamos?usuarioId=${usuarioId}&libroId=${libroId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
            });

            if (res.ok) {
                alert('Préstamo registrado correctamente.');
                // Recargar las tres secciones
                cargarOpciones(); 
                listarPrestamosActivos(); 
                cargarHistorialCompleto();
            } else {
                const errorText = await res.text();
                alert(`Error al registrar préstamo: ${errorText}`);
            }
        } catch (error) {
            console.error('Error de conexión al prestar:', error);
            alert('No se pudo conectar al servidor para prestar el libro.');
        }
    });
}

// Registrar Devolución (Llamada desde el botón en la tabla) 
window.devolverLibro = async function(prestamoId) {
    if (!confirm(`¿Estás seguro de devolver el préstamo ID: ${prestamoId}?`)) {
        return;
    }

    try {
        const res = await fetch(`${API_URL}/api/prestamos/${prestamoId}/devolucion`, {
            method: 'POST' 
        });

        if (res.ok) {
            const result = await res.json();
            alert(`Devolución registrada. Multa: $${result.multa.toFixed(2)} pesos.`);
            // Recargar las tres secciones
            cargarOpciones(); 
            listarPrestamosActivos(); 
            cargarHistorialCompleto();
        } else {
            const errorText = await res.text();
            alert(`Error al devolver: ${errorText}`);
        }
    } catch (error) {
        console.error('Error de conexión al devolver:', error);
        alert('No se pudo conectar al servidor para la devolución.');
    }
}


                // Funciones de Listado de Tablas 
// Listar Préstamos activos
async function listarPrestamosActivos(filtro = '') {
    try {
        const res = await fetch(`${API_URL}/api/prestamos/activos`);
        const prestamos = await res.json();
        
        tablaActivos.innerHTML = '';

        prestamos.filter(p => 
            p.usuario.nombre.toLowerCase().includes(filtro.toLowerCase()) || 
            p.libro.titulo.toLowerCase().includes(filtro.toLowerCase())
        ).forEach(p => {
            // Lógica para calcular fecha límite y si está tarde
            const fechaLimite = new Date(p.fechaPrestamo);
            fechaLimite.setDate(fechaLimite.getDate() + 3);
            
            const esTarde = new Date() > fechaLimite;
            
            const fila = document.createElement('tr');
            fila.style.backgroundColor = esTarde ? '#f8d7da' : 'inherit'; // Resalta si está tarde
            
            fila.innerHTML = `
                <td>${p.prestamoID}</td>
                <td>${p.usuario.nombre} ${p.usuario.apellidos}</td>
                <td>${p.libro.titulo}</td>
                <td>${new Date(p.fechaPrestamo).toLocaleDateString()}</td>
                <td>${fechaLimite.toLocaleDateString()}</td>
                <td><button class="devolver-btn" onclick="devolverLibro(${p.prestamoID})">Devolver</button></td>
            `;
            tablaActivos.appendChild(fila);
        });
    } catch (error) {
        console.error('Error al listar préstamos activos:', error);
        if (tablaActivos) tablaActivos.innerHTML = '<tr><td colspan="6">Error al cargar la lista de activos.</td></tr>';
    }
}

// Listar Historial completo 
async function cargarHistorialCompleto() {
    try {
        const res = await fetch(`${API_URL}/api/prestamos`);
        historialCompleto = await res.json(); 
        
        mostrarHistorial(historialCompleto);
    } catch (error) {
        console.error('Error al cargar historial completo:', error);
        if (tablaHistorial) tablaHistorial.innerHTML = '<tr><td colspan="6">Error al cargar el historial.</td></tr>';
    }
}

function mostrarHistorial(lista) {
    tablaHistorial.innerHTML = '';
    if (lista.length === 0) {
        tablaHistorial.innerHTML = '<tr><td colspan="6">No hay registros en el historial.</td></tr>';
        return;
    }

    lista.forEach(p => {
        const estado = p.fechaDevolucion ? 'Devuelto' : 'Activo';
        const multa = p.multa > 0 ? `<span style="color: red;">$${p.multa.toFixed(2)}</span>` : 'Ninguna';
        
        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${p.prestamoID}</td>
            <td>${p.usuario.nombre} ${p.usuario.apellidos}</td>
            <td>${p.libro.titulo}</td>
            <td>${new Date(p.fechaPrestamo).toLocaleDateString()}</td>
            <td>${p.fechaDevolucion ? new Date(p.fechaDevolucion).toLocaleDateString() : 'PENDIENTE'}</td>
            <td>${multa}</td>
        `;
        tablaHistorial.appendChild(fila);
    });
}

// Lógica del Filtro avanzado
window.filtrarHistorial = function() {
    const nombreFiltro = document.getElementById('filtroNombre').value.toLowerCase();
    const inicioFiltro = document.getElementById('filtroFechaInicio').value;
    const finFiltro = document.getElementById('filtroFechaFin').value;

    let listaFiltrada = historialCompleto.filter(p => {
        const coincideNombre = p.usuario.nombre.toLowerCase().includes(nombreFiltro) || 
                               p.libro.titulo.toLowerCase().includes(nombreFiltro);
        
        let coincideFecha = true;
        if (inicioFiltro) {
            coincideFecha = coincideFecha && (new Date(p.fechaPrestamo) >= new Date(inicioFiltro));
        }
        if (finFiltro) {
            coincideFecha = coincideFecha && (new Date(p.fechaPrestamo) <= new Date(finFiltro));
        }
        
        return coincideNombre && coincideFecha;
    });
    
    mostrarHistorial(listaFiltrada);
}


//  Inicialización General 
document.addEventListener('DOMContentLoaded', () => {
    // La carga inicial de opciones (usuarios y libros)
    cargarOpciones();
    
    // Inicialización de las tablas
    listarPrestamosActivos(); 
    cargarHistorialCompleto();

    // Evento de filtro para la tabla de activos
    if (filtroActivosInput) {
        filtroActivosInput.addEventListener('input', (e) => {
            listarPrestamosActivos(e.target.value);
        });
    }
});