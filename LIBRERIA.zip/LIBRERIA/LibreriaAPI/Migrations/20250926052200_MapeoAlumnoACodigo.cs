﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LibreriaAPI.Migrations
{
    /// <inheritdoc />
    public partial class MapeoAlumnoACodigo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Prestamos_Usuarios_UsuarioID",
                table: "Prestamos");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Usuarios",
                table: "Usuarios");

            migrationBuilder.RenameTable(
                name: "Usuarios",
                newName: "Alumnos");

            migrationBuilder.RenameColumn(
                name: "UsuarioId",
                table: "Alumnos",
                newName: "AlumnoID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Alumnos",
                table: "Alumnos",
                column: "AlumnoID");

            migrationBuilder.AddForeignKey(
                name: "FK_Prestamos_Alumnos_UsuarioID",
                table: "Prestamos",
                column: "UsuarioID",
                principalTable: "Alumnos",
                principalColumn: "AlumnoID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Prestamos_Alumnos_UsuarioID",
                table: "Prestamos");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Alumnos",
                table: "Alumnos");

            migrationBuilder.RenameTable(
                name: "Alumnos",
                newName: "Usuarios");

            migrationBuilder.RenameColumn(
                name: "AlumnoID",
                table: "Usuarios",
                newName: "UsuarioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Usuarios",
                table: "Usuarios",
                column: "UsuarioId");

            migrationBuilder.AddForeignKey(
                name: "FK_Prestamos_Usuarios_UsuarioID",
                table: "Prestamos",
                column: "UsuarioID",
                principalTable: "Usuarios",
                principalColumn: "UsuarioId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
