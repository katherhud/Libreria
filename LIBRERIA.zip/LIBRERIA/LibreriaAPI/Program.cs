using System.IO;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.StaticFiles;
using LibreriaAPI.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
// Conexi�n a BD
builder.Services.AddDbContext<LibreriaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(
        policy =>
        {
            // Esto permite cualquier origen, m�todo o encabezado.
            policy.AllowAnyOrigin()
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
// 1. Aplicacion de archivos est�ticos y default files aqui
app.UseDefaultFiles(new DefaultFilesOptions
{
    DefaultFileNames = new List<string> { "inicio.html", "index.html" }
});
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(
        // Debido a que en la carpeta Frontend est� fuera del proyecto, agregamos un nivel mas arriba 
        //para que pueda encontrar los archivos del frontend
        Path.Combine(Directory.GetCurrentDirectory(), "..", "Frontend")),
    RequestPath = "" // Sirve desde la ra�z (/)
});


app.UseRouting();
app.UseCors();

app.UseAuthorization();
app.MapControllers();
app.Run();



