﻿using LibreriaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace LibreriaAPI.Data
{
    public class LibreriaContext : DbContext
    {
        public LibreriaContext(DbContextOptions<LibreriaContext> options) : base(options) { }
        // Aqui se hace la conexion de la base de datos con los datos del programa, 
        //se consolida la union de los datos (esto porque usamos nombres distinto en la base y en el programa)
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Libro> Libros { get; set; }
        public DbSet<Prestamo> Prestamos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuración de Usuario (Alumnos)
            modelBuilder.Entity<Usuario>()
                .ToTable("Alumnos")
                // Ignoramos la colección de navegación 
                .Ignore(u => u.Prestamos)
                // Ignoramos la columna activa del modelo para el registro/listado directo
                .Ignore(u => u.PrestamosActivos);

            // Configuraciones de otras tablas 
            modelBuilder.Entity<Libro>().ToTable("Libros");
            modelBuilder.Entity<Prestamo>().ToTable("Prestamos");

            base.OnModelCreating(modelBuilder);
        }
    }
}

