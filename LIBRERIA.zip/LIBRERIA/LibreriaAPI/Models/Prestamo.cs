﻿

using LibreriaAPI.Models;
using System;

namespace LibreriaAPI.Models
{
    public class Prestamo
    {
        public int PrestamoID { get; set; }

        public int UsuarioID { get; set; }
        public Usuario? Usuario { get; set; }

        public int LibroID { get; set; }
        public Libro? Libro { get; set; }

        public DateTime FechaPrestamo { get; set; } = DateTime.Now;
        public DateTime? FechaDevolucion { get; set; }
        public decimal Multa { get; set; }
    }
}


