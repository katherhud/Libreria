﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibreriaAPI.Models
{
    public class Usuario
    {
        [Key]
        [Column("AlumnoID")]
        public int UsuarioId { get; set; }

        public string Matricula { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string? Telefono { get; set; }

        // Inicializamos a 0 al crear un objeto C#
        public int PrestamosActivos { get; set; } = 0;

        public ICollection<Prestamo>? Prestamos { get; set; }
    }
}

