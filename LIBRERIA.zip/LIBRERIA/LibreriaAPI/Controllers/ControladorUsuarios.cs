﻿using LibreriaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using LibreriaAPI.Data;
using System.Linq;

namespace LibreriaAPI.Controllers
{
    // Nombre del controlador
    [ApiController]
    [Route("api/usuarios")]
    public class UsuariosController : ControllerBase
    {
        private readonly LibreriaContext _context;

        public UsuariosController(LibreriaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetUsuarios()
        {
            // Esto solo lista las propiedades que NO ignoramos (Matricula, Nombre, etc.)
            return Ok(_context.Usuarios.ToList());
        }

        [HttpPost]
        public IActionResult CrearUsuario([FromBody] Usuario usuario)
        {
            if (string.IsNullOrEmpty(usuario.Matricula))
                return BadRequest("La matrícula es obligatoria.");

            // Aseguramos que PrestamosActivos sea 0 al agregar usuarios 
            //(el usuario no puede registrarse con prestamos activos)
            usuario.PrestamosActivos = 0;

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();
            return Ok(usuario);
        }
    }
}
