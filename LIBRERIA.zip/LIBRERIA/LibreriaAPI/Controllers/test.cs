﻿using Microsoft.AspNetCore.Mvc;
using LibreriaAPI.Data;

namespace LibreriaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestDbController : ControllerBase
    {
        private readonly LibreriaContext _context;

        public TestDbController(LibreriaContext context)
        {
            _context = context;
        }

        // GET: api/testdb
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Intenta conectarse a la base de datos
                var canConnect = _context.Database.CanConnect();
                return Ok(new { ConexionExitosa = canConnect });
            }
            catch (Exception ex)
            {
                return BadRequest(new { ConexionExitosa = false, Error = ex.Message });
            }
        }
    }
}
