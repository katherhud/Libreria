﻿using LibreriaAPI.Data;
using LibreriaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibreriaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PrestamosController : ControllerBase
    {
        private readonly LibreriaContext _context;

        public PrestamosController(LibreriaContext context)
        {
            _context = context;
        }

        // Historial de préstamos (GET/api/prestamos)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Prestamo>>> GetAll()
        {
            return await _context.Prestamos
                .Include(p => p.Usuario)
                .Include(p => p.Libro)
                .ToListAsync();
        }

        // Préstamos activos (GET/api/prestamos/activos)
        [HttpGet("activos")]
        public async Task<ActionResult<IEnumerable<Prestamo>>> GetActivos()
        {
            return await _context.Prestamos
                .Include(p => p.Usuario)
                .Include(p => p.Libro)
                .Where(p => p.FechaDevolucion == null)
                .ToListAsync();
        }

        //Registrar préstamo (POST/api/prestamos)
        [HttpPost]
        public async Task<ActionResult> CrearPrestamo(int usuarioId, int libroId)
        {
            // 1. Verificar existencia del Usuario y Libro (usando la capitalización UsuarioId)
            var usuario = await _context.Usuarios
                                        .FirstOrDefaultAsync(u => u.UsuarioId == usuarioId);

            var libro = await _context.Libros.FindAsync(libroId);

            if (usuario == null || libro == null)
                return BadRequest("Usuario o libro no encontrado");

            // 2. Contar préstamos activos de forma eficiente
            // Cuenta cuántos préstamos tiene este usuario que aún no tienen FechaDevolucion
            var prestamosActivos = await _context.Prestamos.CountAsync(p => p.UsuarioID == usuarioId
            && p.FechaDevolucion == null);


            // 3. Aplicación de Lógica Límite de 3 libros
            if (prestamosActivos >= 3)
                return BadRequest($"El usuario '{usuario.Nombre}' ya tiene el límite de 3 préstamos activos.");

            if (!libro.Disponible)
                return BadRequest($"El libro '{libro.Titulo}' no está disponible.");

            // 4. Registrar nuevo préstamo
            var prestamo = new Prestamo
            {
                UsuarioID = usuarioId,
                LibroID = libroId,
                FechaPrestamo = DateTime.Now,
                Multa = 0
            };

            // 5. Actualizar estados y guardar
            libro.Disponible = false;
            _context.Prestamos.Add(prestamo);

            usuario.PrestamosActivos = prestamosActivos + 1;

            await _context.SaveChangesAsync();

            return Ok("Préstamo registrado correctamente");
        }

        // Registrar devolución (POST/api/prestamos/{prestamoId}/devolucion) 
        [HttpPost("{prestamoId}/devolucion")]
        public async Task<ActionResult> DevolverPrestamo(int prestamoId)
        {
            var prestamo = await _context.Prestamos
                .Include(p => p.Libro)
                .FirstOrDefaultAsync(p => p.PrestamoID == prestamoId);

            if (prestamo == null)
                return NotFound("Préstamo no encontrado");

            if (prestamo.FechaDevolucion != null)
                return BadRequest("El préstamo ya fue devuelto");

            // 1. Registrar fecha de devolución
            prestamo.FechaDevolucion = DateTime.Now;

            // 2. Calcular Multa: 15 pesos por día extra (límite 3 días)
            var dias = (prestamo.FechaDevolucion.Value - prestamo.FechaPrestamo).TotalDays;
            decimal multaCalculada = 0;

            if (dias > 3)
            {
                multaCalculada = (decimal)Math.Ceiling(dias - 3) * 15; // Usar Math.Ceiling para contar el día incompleto
            }
            prestamo.Multa = multaCalculada;

            // 3. Actualizar el estado del libro y el contador del usuario
            prestamo.Libro.Disponible = true;

            // Decrementar el contador PrestamosActivos del usuario
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.UsuarioId == prestamo.UsuarioID);
            if (usuario != null && usuario.PrestamosActivos > 0)
            {
                usuario.PrestamosActivos--;
            }

            // 4. Guardar cambios
            await _context.SaveChangesAsync();

            return Ok(new { mensaje = "Devolución registrada", multa = prestamo.Multa });
        }
    }
}